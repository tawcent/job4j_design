package ru.job4j.collection;

public class Loop {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 0; i < 15; i++) {
            sum += i;
        }
        System.out.println("sum = " + sum);
    }
}
